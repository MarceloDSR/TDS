export class Owl {
    name: string;
    weight: number;

    constructor(name: string, weight: number) {
        this.name = name;
        this.weight = weight;
    }

    chirp(): void {
        console.log("Hu hu");
    }
    
    eat(quantity: number) {
        console.log("the little owl has eaten " + quantity);
        
    }

    fly(time: number) {
        console.log("the little owl flown for " + time + " minutes");
    }
}