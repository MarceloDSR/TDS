import { Guerreiro }  from "./Guerreiro"
import { Monstro } from "./Monstro"

let guerreiroAssassino = new Guerreiro("Fury", "Assassino", 5)
let newMonster = new Monstro("Berguns")


guerreiroAssassino.info()
newMonster.info()

newMonster.atacar(guerreiroAssassino)
guerreiroAssassino.ataque(newMonster)