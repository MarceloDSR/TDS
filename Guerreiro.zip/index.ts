import { Dog } from "./Dog";
import { Owl } from "./Owl";

let cachorroDoEdilson = new Dog("Maike", 12.5);

console.log(cachorroDoEdilson.name);
cachorroDoEdilson.bark();

let corujaDoHarry = new Owl("Edwiges", 6.5);

console.log(corujaDoHarry.name);
corujaDoHarry.chirp();