import { Monstro } from "./Monstro";

export class Guerreiro {
    name: string;
    type: string;
    strength: number;
    health: number

    constructor(name: string, type: string, strength: number) {
        this.name = name;
        this.type = type;
        this.strength = strength
        this.health = 100
    }

    info(){
        console.log(`Name: ${this.name}, type: ${this.type}, Strength: ${this.strength}, Heal: ${this.health}.`)
    }
    ataque(monstro: Monstro): void{
        console.log(`Atacar!!!`)
        console.log(`The warrior attacked the warrior with a total of damage ${this.strength}`)
    }

    recebeDano(guerreiro: Guerreiro){
        console.log("ARGG!")
        console.log(`The monster attacked the warrior with a total of damage ${this.strength}`)
    }


}