import { Guerreiro } from "./Guerreiro";

export class Monstro {
    name: string;
    strength: number;
    health: number

    constructor(name: string) {
        this.name = name;
        this.strength = 50
        this.health = 10
    }

    info(){
        console.log(`Name: ${this.name}, Strength: ${this.strength}, Heal: ${this.health}.`)
    }
    atacar(guerreiro: Guerreiro): void{
        let atacar = this.strength
        console.log(`Atacar!!!`)
        console.log(`The Monster attacked the warrior with a total of damage ${this.strength}`)
    }


    recebeDano(monstro: Monstro){
        console.log("ARGG!")
        console.log(`The warrior attacked the monster with a total of damage ${this.strength}`)
    }
}