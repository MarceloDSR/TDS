//uma classe sempre se escreve com a primeira letra maiuscula e sempre no singular
// attributtes
 export class Dog {
    name: string;
    weight: number;


    constructor(name: string, weight: number) {
        this.name = name;
        this.weight = weight;
    }

    //methods
    bark(): void {
        console.log("Au au");
    }

    eat(quantity: number): void{
        console.log("The dog has eaten " + quantity)
    }
}